export const APP_URL = "https://honey-tyagi-spotify-clone.vercel.app";
